package Lab8;

public class Third {
    public static void main(String[] args) {
        int min = 0;
        int max = 101;

        int a = (int) (Math.random() * (max - min)) + min;
        int b = String.valueOf(a).length();//щоб перетворити його на рядок

        System.out.println("Випадкове число: " + a);
        System.out.println("Кількість цифр: " + b);
    }
}
