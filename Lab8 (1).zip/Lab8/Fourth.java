package Lab8;
import java.util.Scanner;
public class Fourth {
    public static void main(String[] args) {
        int min = 1;
        int max = 3;
        int attempts = 2;

        int number1 = generateRandomNumber(min, max);
        int number2 = generateRandomNumber(min, max);
        int number3 = generateRandomNumber(min, max);

        System.out.println("Ласкаво просимо до гри \"Лотерея\"!");
        System.out.println("Спробуйте відгадати послідовність трьох чисел від 1 до 3.");

        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < attempts; i++) {
            System.out.print("Спроба " + (i + 1) + ": Введіть три числа через пробіл: ");
            int a1 = scanner.nextInt();
            int a2 = scanner.nextInt();
            int a3 = scanner.nextInt();

            if (a1 == number1 && a2 == number2 && a3 == number3) {
                System.out.println("Вітаємо! Ви відгадали правильну послідовність чисел.");
                return;
            } else {
                System.out.println("Ви не відгадали. Спробуйте ще раз.");
            }
        }

        System.out.println("Гра закінчена. Ви не відгадали правильну послідовність чисел.");
        System.out.println("Правильна послідовність: " + number1 + " " + number2 + " " + number3);
    }

    public static int generateRandomNumber(int min, int max) { //використовується для генерації одного числа з проміжку.
        return (int) (Math.random() * (max - min + 1)) + min;
    }
}
