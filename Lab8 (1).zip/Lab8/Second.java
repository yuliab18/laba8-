package Lab8;

public class Second {
    public static void main(String[] args) {
        int a = 3; // Довжина першого катета
        int b = 4; // Довжина другого катета

        double hypotenuse = Math.sqrt(a * a + b * b); // Визначення гіпотенузи
        double perimeter = a + b + hypotenuse; // Визначення периметра
        double area = (a * b) / 2.0; // Визначення площі

        System.out.println("Гіпотенуза: " + hypotenuse);
        System.out.println("Периметр: " + perimeter);
        System.out.println("Площа: " + area);
    }
}
